from odoo import models, api, fields


class Todo(models.Model):
    _name = 'todo_tasks'
    task_name = fields.Char(tracking=1)
    assign_to = fields.Many2one('res.partner')
    description = fields.Text(tracking=1)
    due_date = fields.Date()
    _inherit = ['mail.thread', 'mail.activity.mixin']
    status = fields.Selection(
        [
            ('new', 'New'),
            ('in progress', 'In Progress'),
            ('completed', 'Completed')
        ], default= ('new')
    )


    def action_new(self):
        for rec in self:
            rec.status = 'new'

    def action_in_progress(self):
        for rec in self:
            rec.status = 'in progress'


    def action_completed(self):
        for rec in self:
            rec.status = 'completed'





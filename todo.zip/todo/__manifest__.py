{
    'name': "TODO App",
    'author': "maged",
    'category': '',
    'version': '17.1.1',
    'depends': ['base'],
    'data':[
        'views/main_menu.xml',
        'views/todo_tasks.xml',
        'security/ir.model.access.csv'
    ],
    'depends': ['base', 'mail','contacts'],
    'application': True,
}
